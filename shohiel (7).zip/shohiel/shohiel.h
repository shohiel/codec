#ifndef SHOHIEL_H
#define SHOHIEL_H

#include <Wire.h>

class Shohiel {
public:
    Shohiel(uint8_t lcdAddr, uint8_t lcdCols, uint8_t lcdRows);
    void begin();
    void clear();
    void home();
    void setCursor(uint8_t col, uint8_t row);
    void print(const char *message);
    void backlight(bool enable);

private:
    void sendCommand(uint8_t command);
    void sendData(uint8_t data);
    void write4bits(uint8_t value);
    void pulseEnable(uint8_t value);

    uint8_t _lcdAddr;
    uint8_t _lcdCols;
    uint8_t _lcdRows;
    uint8_t _backlightVal;
};

#endif
