#include "Shohiel.h"

// Commands for the LCD
#define LCD_CLEAR_DISPLAY 0x01
#define LCD_RETURN_HOME   0x02
#define LCD_ENTRY_MODE    0x04
#define LCD_DISPLAY_CTRL  0x08
#define LCD_CURSOR_SHIFT  0x10
#define LCD_FUNCTION_SET  0x20
#define LCD_SET_CGRAM     0x40
#define LCD_SET_DDRAM     0x80

// Flags for display entry mode
#define ENTRY_LEFT        0x02

// Flags for display on/off control
#define DISPLAY_ON        0x04
#define CURSOR_OFF        0x00
#define BLINK_OFF         0x00

// Flags for function set
#define FUNC_4BIT_MODE    0x00
#define FUNC_2LINE        0x08
#define FUNC_5x8DOTS      0x00

// Bit control
#define ENABLE_BIT        0x04
#define READ_WRITE_BIT    0x02
#define REGISTER_SELECT   0x01

Shohiel::Shohiel(uint8_t lcdAddr, uint8_t lcdCols, uint8_t lcdRows)
    : _lcdAddr(lcdAddr), _lcdCols(lcdCols), _lcdRows(lcdRows), _backlightVal(0x08) {}

void Shohiel::begin() {
    Wire.begin();
    delay(50);

    // Initialize the LCD in 4-bit mode
    write4bits(0x03 << 4);
    delay(5);
    write4bits(0x03 << 4);
    delay(5);
    write4bits(0x03 << 4);
    delay(1);
    write4bits(0x02 << 4); // Set to 4-bit mode

    // Configure the display
    sendCommand(LCD_FUNCTION_SET | FUNC_4BIT_MODE | FUNC_2LINE | FUNC_5x8DOTS);
    sendCommand(LCD_DISPLAY_CTRL | DISPLAY_ON | CURSOR_OFF | BLINK_OFF);
    sendCommand(LCD_CLEAR_DISPLAY);
    sendCommand(LCD_ENTRY_MODE | ENTRY_LEFT);
}

void Shohiel::clear() {
    sendCommand(LCD_CLEAR_DISPLAY);
    delay(2);
}

void Shohiel::home() {
    sendCommand(LCD_RETURN_HOME);
    delay(2);
}

void Shohiel::setCursor(uint8_t col, uint8_t row) {
    uint8_t rowOffsets[] = {0x00, 0x40, 0x14, 0x54};
    if (row >= _lcdRows) row = _lcdRows - 1;
    sendCommand(LCD_SET_DDRAM | (col + rowOffsets[row]));
}

void Shohiel::print(const char *message) {
    while (*message) {
        sendData(*message++);
    }
}

void Shohiel::backlight(bool enable) {
    _backlightVal = enable ? 0x08 : 0x00;
    Wire.beginTransmission(_lcdAddr);
    Wire.write(_backlightVal);
    Wire.endTransmission();
}

void Shohiel::sendCommand(uint8_t command) {
    write4bits(command & 0xF0);
    write4bits((command << 4) & 0xF0);
}

void Shohiel::sendData(uint8_t data) {
    write4bits((data & 0xF0) | REGISTER_SELECT);
    write4bits(((data << 4) & 0xF0) | REGISTER_SELECT);
}

void Shohiel::write4bits(uint8_t value) {
    Wire.beginTransmission(_lcdAddr);
    Wire.write(value | _backlightVal);
    Wire.endTransmission();
    pulseEnable(value);
}

void Shohiel::pulseEnable(uint8_t value) {
    Wire.beginTransmission(_lcdAddr);
    Wire.write(value | ENABLE_BIT | _backlightVal);
    Wire.endTransmission();
    delayMicroseconds(1);

    Wire.beginTransmission(_lcdAddr);
    Wire.write((value & ~ENABLE_BIT) | _backlightVal);
    Wire.endTransmission();
    delayMicroseconds(50);
}
